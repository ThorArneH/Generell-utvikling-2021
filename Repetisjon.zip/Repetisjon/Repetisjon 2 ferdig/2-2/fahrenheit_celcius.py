print ("Skriv inn fahrenheit")
fahrenheit = input ("")
#Spør om og får nummer

fahrenheit = int(fahrenheit)
#gjør om fahrenheit nummeret til int sånn at det kan regnes
celcius = (((fahrenheit)-32)*5/9)
#formel gjør om fahrenheit til celcius

celcius = str (celcius) #Gjør celcius til str sånn at jeg kan skrive bak
print (celcius + " grader celcius") # Printer ut celcius
