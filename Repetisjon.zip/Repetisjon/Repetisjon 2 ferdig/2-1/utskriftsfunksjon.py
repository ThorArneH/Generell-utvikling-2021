def navnBosted():
    navn = input ("Skriv inn navn")
    bosted = input ("Hvor kommer du fra?")
    print ("Hei, " + navn + " du er fra " + bosted + ".")
#Funksjonen, den spør om navn og bosted og skriver det ut

navnBosted()
navnBosted()
navnBosted()