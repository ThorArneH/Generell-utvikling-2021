måltid = {
    "Kari": ["Egg&bacon, Baguetter, Lasagne"],
    "Thorarne": ["Frokostblanding, Brød&pålegg, Kylling"],
    "Andreas": ["Yoghurt, Smørbrød, Kylling"],
    "Lan": ["Knekkebrød, Fruktsalat, Biff"],
    "Arne": ["Brød, Baguetter, Lapskaus"]
}
#lager en ordbok med alle beboerne sine navn og matplaner

Userinput = input("Skriv inn navn på en beboer: ")
#variabel for input


if Userinput in måltid:
    print (Userinput,"sin matplan er:", måltid[Userinput])
else:
    print (Userinput,"er ikke registrert")
#Spør om navn og printer ut matplanen til opgitt person hvis de er i listen, hvis ikke, sier error

