#R "If "ThorArne" in this list:"

tall = [31, 16, 21]
tall.append (47)
#Lager en liste og appender (legger til) 47 på slutten av listen

print (tall[0], tall[2])
#printer ut tall 1 og 3



sum = (tall[0] + tall[1] + tall[2] + tall[3])
print (sum)
#adderer
produkt = (tall[0] * tall[1] * tall[2] * tall[3])
print (produkt)
#multipliserer

resultater = [sum, produkt]
#liste med resultater



prodtall = tall+resultater
print (prodtall)
#setter sammen lister og printer ut

prodtall.pop()
prodtall.pop()
print (prodtall)
#fjerner 2 bakerste elementer og printer ut


navn = [input("Skriv inn navn 1: "), input("Skriv inn navn 2: "), input("Skriv inn navn 3: "), input("Skriv inn navn 4: ")]
navn = [x.lower() for x in navn]
#Spør om navn og gjør dem til små bokstaver sånn at "if" kan kjenne igjen navn

if "thorarne" in navn:
    print ("Du husket meg!")

elif "thor arne" in navn:
    print ("Du husket meg!")

else:
    print ("Glemte du meg?")