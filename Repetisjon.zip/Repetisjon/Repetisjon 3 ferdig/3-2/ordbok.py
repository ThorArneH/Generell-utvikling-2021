handleliste = {
  "Melk": 14.90,
  "Brød": 24.90,
  "Yoghurt": 12.90,
  "Pizza": 39.90
}
#lager ordbok

print ("Handleliste: ",  handleliste)
#printer ordbok


handleliste.update({
    input ("Skriv inn vare: "): input ("Legg til en pris: "),
    input ("Skriv inn en til vare: "): input ("Legg til en til pris")
    })
#legger til handlelista


print ("Oppdatert Handleliste: ", handleliste)
#printer ordbok igjen