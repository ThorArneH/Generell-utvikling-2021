def billettkontroll():
    navn =  input ("Vennligst oppgi navn: ")
    alder = int(input ("Vennligst oppgi alder: "))
    #int(input) fordi <= tar ikke str og integers

    if alder <= 17:
        print ("Hei " + navn + ", Prisen din blir 30kr")
    
    elif alder < 63:
        print ("Hei " + navn + ", Prisen din blir 50kr")

    else:
        print ("Hei " + navn + ", Prisen din blir 35kr")
#Funksjon som spør om navn + alder og gir pris


billettkontroll()
#Kjører funksjonen