nummer = int(input("Skriv nummer: "))
#Tar et nummer

nummerliste = []
nummerliste.append(nummer)
#lager en tom liste og legger til tall

while nummer != 0:
    nummer = int(input("Skriv et til: "))
    nummerliste.append(nummer)
#Sjekker om nummer er 0, hvis ikke så spør den om et til. Legger til tall til den tomme listen

for x in nummerliste:
    print (x)
#printer hvert enkelt element



minSum = 0

for x in nummerliste:
    minSum += x

print ("Summen er", minSum)
#Summerer hele listen


største=nummerliste[0]
for x in nummerliste:
    if x > største:
        største=x
print("Det største taller er:", største)
#Finner det største nummeret


minste=nummerliste[0]
for x in nummerliste:
    if x < minste:
        minste=x
print("Det minste taller er:", minste)
#Finner den minste nummeret