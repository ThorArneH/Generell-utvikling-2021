mineOrd = []
#Lager en tom liste


def slaaSammen(str1, str2):
    slatt = str1 + str2
    return slatt
#Funksjon som slår sammen 2 strenger


def skrivUt(Liste):
    for x in Liste:
        print (x)
#Funksjon som skriver ut liste ord for ord


answer = input(str("""
i = Slå sammen,
u = Skriv ut,
s = Avslutt,

Hva ønsker du å gjøre?: """))
#Spør bruker om hva de vil gjøre

while answer != "s":
    if answer == "i":
        mineOrd.append (slaaSammen(input("Skriv in et ord: "), input("Skriv in et ord til: ")))
    #Hvis bruker svarer "s" kjører ikke løkken, hvis bruker svarer "i" kjører dette som legger til et ord i liste etter å ha slått sammen

    if answer == "u":
        skrivUt(mineOrd)
    #Hvis brukeren svarer "u" så printer den ut listen

    answer = input(str("""
       
        i = Slå sammen,
        u = Skriv ut,
        s = Avslutt,

        Hva ønsker du å gjøre?: """))
    #Spør bruker hva den vil gjøre videre