reisemål = []

nummer = 0

for x in range(5):
    nummer += 1
    reisemål.append(input("Skriv inn reisemål %s: " %nummer))
#Lager en tom liste og legger til 5 reisemål fra brukeren



klesplagg = []

nummer = 0

for x in range(5):
    nummer += 1
    klesplagg.append(input("Skriv inn klesplagg %s: " %nummer))
#Lager en tom liste og legger til 5 reisemål fra brukeren



avreisedato = []

nummer = 0

for x in range(5):
    nummer += 1
    avreisedato.append(input("Skriv inn avreisedato %s: " %nummer))
#Lager en tom liste og legger til 5 reisemål fra brukeren


reiseplan = [reisemål, klesplagg, avreisedato]
#Lager en liste med alle listene

for x in reiseplan:
    print (x)
#Printer alt


i1 = int(input("Skriv inn nummer fra 0-2"))
i2 = int(input("Skriv inn nummer fra 0-4"))
#spør om nummere

if i1 > 2 or i1 < 0:
    print ("Ugyldig input!")
elif i2 > 4 or i1 < 0:
    print ("Ugyldig input!")
#sjekker om nummere er 0-2 eller 0-4

else:
    print (reiseplan [i1][i2])
#Printer ut valgte ting