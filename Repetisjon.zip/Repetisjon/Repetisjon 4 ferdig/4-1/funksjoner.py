def adder (tall1, tall2):
    sum = tall1 + tall2
    print ("Summen av ",  tall1, "+", tall2,  " er ",  sum)
#Funksjon med 2 argumenter som adderer og printer svar

adder(12, 13)
adder(25, 36)
#Kaller funksjonen 2 ganger



def tellForekomst (minTekst, minBokstav):
    occurences = minTekst.count(minBokstav)
    print ("Det er", occurences, minBokstav, "i", minTekst)
    #Funksjon for punkt 3, spør om tekst og bokstav og teller hvor mange bokstaver i tekst


tellForekomst(
    input ("Skriv inn tekst: "),
    input ("Skriv inn en bokstav: ")
)
#Skrevet om punkt 2, aka flyttet alt til funksjonen og kalte på den
