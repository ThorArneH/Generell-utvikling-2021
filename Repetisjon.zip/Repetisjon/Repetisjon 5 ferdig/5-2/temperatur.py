Temp = []
#Lager en tom liste

with open(r'C:\Users\floyd\Desktop\Skole greier 2021-2022\Utvikling\Repetisjon\Repetisjon 5\5-2\temperatur.txt', 'rt') as fil:
    for i in fil:
        Temp.append (i.strip())
#Åpner txt filen for lesing og legger alle tallene inn i den tomme listen, strip er for å fjerne newlines (\n)


def gjennomsnitt(liste):
    liste = [int(x) for x in liste]
    return sum(liste) / len(liste)
#Lager funksjon som finner gjennomsnittet i listen, første linje gjør liste til int også andre linje finner gjennomsnitt


print (gjennomsnitt(Temp), "er gjennomsnittlig temperatur gjennom året")