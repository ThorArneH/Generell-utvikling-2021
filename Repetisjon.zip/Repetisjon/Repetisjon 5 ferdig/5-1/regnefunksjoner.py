def addisjon(nummer1, nummer2):
    return nummer1 + nummer2

def subtraksjon(nummer1, nummer2):
    return nummer1-nummer2

def divisjon(nummer1, nummer2):
    return nummer1/nummer2

def tommerTilCm(antallTommer):
    return antallTommer*2.54

#Funksjoner som gjør navnet deres (regner)


def skrivBeregninger(): #Lager en funksjon
    tall1 = (int(input("Skriv inn et tall: ")))
    tall2 = (int(input("Skriv inn et tall til: ")))
    #Spør om 2 tall som den kan bruke

    print (addisjon(tall1, tall2))
    print (subtraksjon(tall1, tall2))
    print (divisjon(tall1, tall2))
    #Kaller og gir funksjoner tallene, skriver ut etter

    tom = (int(input("Gi meg et siste tall: ")))
    print (tommerTilCm(tom))
    #Spør om et siste tall og gjør det om fra tommer til cm



skrivBeregninger()
#Kaller på funksjonen