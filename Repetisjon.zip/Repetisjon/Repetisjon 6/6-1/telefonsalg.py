ansatteSalg = {}
#lager ordbok

def innlesning(filnavn):

    fil = open (filnavn)
    
    for tekst in fil:
        key, value = tekst.split() #Splitter opp teksten

        ansatteSalg[key] = value #legger det inn i ordbok
#Lager en funksjon som heter innlesning, den leser inn filer inn i ordboken


innlesning("salgstall.txt") #kaller funksjon

def maanedensSalgsperson(ordbok):
    for tekst in ordbok:
        value = tekst.split()

        return max(value)#Funker ikke btw

print (maanedensSalgsperson(ansatteSalg))
print (ansatteSalg)