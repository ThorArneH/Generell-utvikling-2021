brus = input ("Kunne du tenkt deg en brus?")
#spør bruker om de vil ha en brus?


if brus.lower() == "ja":
    print ("Her har du en brus!")
#Hvis takker ja til brus, .lower sånn at det tar imot Ja med stor bokstav også

elif brus.lower() == "nei":
    print ("Den er grei.")
#Hvis takker nei til brus, .lower samma som forrige

else:
    print ("Det forstod jeg ikke helt.")
#Hvis de ikke svarer ja eller nei