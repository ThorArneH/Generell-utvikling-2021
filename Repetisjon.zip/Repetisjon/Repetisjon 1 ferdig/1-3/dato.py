print ("Vennligst skriv inn numre")
dag = input ("Skriv inn en dag:")
måned = input ("Skriv inn en måned:")

dato = måned + (".") + dag


dag2 = input ("Skriv inn en til dag:")
måned2 = input ("Skriv inn en til måned:")

dato2 = måned2 + (".") + dag2
#Spør om datoer og lager dato variabler på dato1 & 2
#Oppg 2 var litt forvirrende


if dato < dato2:
    print ("Riktig rekkefølge!")

elif dato > dato2:
    print ("Feil rekkefølge!")

elif dato == dato2:
    print ("Samme dato!")
