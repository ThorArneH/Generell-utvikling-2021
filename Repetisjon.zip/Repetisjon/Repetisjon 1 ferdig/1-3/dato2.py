dato = input ("Skriv inn dato: mmdd")
dato2 = input ("Skriv inn en til dato: mmdd")


if dato < dato2:
    print ("Riktig rekkefølge!")

elif dato > dato2:
    print ("Feil rekkefølge!")

elif dato == dato2:
    print ("Samme dato!")
