print ("Hallo Verden")


navn = input ("Oppgi navn")
print ("Hei " + navn + "!")
#Spør om navn og printer ut Hei + <navn>!



tall = 17
tall2 = 5

print (tall)
print (tall2)
#2+ Variabler, printer dem ut


tall3 = (tall-tall2)
print ("Differanse:" + str(tall3))
#Finner differansen mellom tidligere variabler, str(tall3) pga error


navn2 = input ("Vennligst oppgi et til navn")
sammen = navn + navn2
print (sammen)
#Spør om et nytt navn og legger det til det første


sammen = navn + (" og ") + navn2
print (sammen)